public class Guitar implements Playable {
    @Override
    public void play() {
        System.out.println("Playing guitar: Strum strum");
    }
}