console.log("Task 7: DOM Manipulation");

// Event class (reuse from before)
class Event {
  constructor(name, date, category, seats) {
    this.name = name;
    this.date = new Date(date);
    this.category = category;
    this.seats = seats;
  }

  checkAvailability() {
    const now = new Date();
    return this.date >= now && this.seats > 0;
  }

  // Register reduces seats or throws error if full/past
  registerUser() {
    if (!this.checkAvailability()) {
      throw new Error(`Cannot register for "${this.name}": Event full or past.`);
    }
    this.seats--;
  }
}

// Sample events array
const events = [
  new Event("Beach Cleanup", "2025-06-30", "Environment", 3),
  new Event("Music Festival", "2025-08-10", "Music", 1),
  new Event("Coding Bootcamp", "2025-06-28", "Education", 15),
];

// Reference to container div
const container = document.querySelector("#events-container");

// Function to create and return event card DOM element
function createEventCard(event) {
  const card = document.createElement("div");
  card.className = "event-card";

  const title = document.createElement("h3");
  title.textContent = event.name;
  card.appendChild(title);

  const details = document.createElement("p");
  details.textContent = `${event.category} | Date: ${event.date.toDateString()} | Seats: ${event.seats}`;
  card.appendChild(details);

  const button = document.createElement("button");
  button.textContent = event.checkAvailability() ? "Register" : "Full / Past";
  button.disabled = !event.checkAvailability();

  // Register button click handler
  button.addEventListener("click", () => {
    try {
      event.registerUser();
      // Update UI after registration
      details.textContent = `${event.category} | Date: ${event.date.toDateString()} | Seats: ${event.seats}`;

      if (!event.checkAvailability()) {
        button.textContent = "Full / Past";
        button.disabled = true;
      }

      alert(`Successfully registered for ${event.name}!`);
    } catch (err) {
      alert(err.message);
    }
  });

  card.appendChild(button);
  return card;
}

// Function to render all events
function renderEvents() {
  container.innerHTML = ""; // clear previous
  events.forEach(event => {
    const card = createEventCard(event);
    container.appendChild(card);
  });
}

// Initial render
renderEvents();
