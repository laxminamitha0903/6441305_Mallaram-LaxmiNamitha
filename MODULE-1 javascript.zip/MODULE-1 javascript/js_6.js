console.log("Task 6: Arrays and Methods");

// Event class from before (you can reuse your previous class)
class Event {
  constructor(name, date, category, seats) {
    this.name = name;
    this.date = new Date(date);
    this.category = category;
    this.seats = seats;
  }

  checkAvailability() {
    const now = new Date();
    return this.date >= now && this.seats > 0;
  }

  printDetails() {
    console.log(`${this.name} (${this.category}) - ${this.date.toDateString()}, Seats: ${this.seats}`);
  }
}

// Starting event list
const events = [
  new Event("Beach Cleanup", "2025-06-30", "Environment", 25),
  new Event("Music Festival", "2025-08-10", "Music", 50),
  new Event("Coding Bootcamp", "2025-06-28", "Education", 15),
];

// 1. Add new event using push()
const newEvent = new Event("Workshop on Baking", "2025-07-15", "Cooking", 20);
events.push(newEvent);
console.log("Added new event:", newEvent.name);

// 2. Filter only music events
const musicEvents = events.filter(ev => ev.category === "Music");
console.log("\n🎵 Music Events:");
musicEvents.forEach(ev => ev.printDetails());

// 3. Use map() to create formatted display strings for all events
const eventCards = events.map(ev => `${ev.name} — A ${ev.category} event on ${ev.date.toDateString()}`);
console.log("\n📋 Event Display Cards:");
eventCards.forEach(card => console.log(card));
