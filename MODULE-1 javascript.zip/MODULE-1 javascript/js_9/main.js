console.log("Loading events asynchronously");

// Reference to HTML elements
const loading = document.querySelector("#loading");
const container = document.querySelector("#events-container");

// Show loading message
loading.style.display = "block";

// Fetch data from events.json
fetch("events.json")
  .then(response => response.json())  // parse JSON from response
  .then(data => {
    loading.style.display = "none";  // hide loading

    // For each event, create a simple card and add to container
    data.forEach(event => {
      const card = document.createElement("div");
      card.style.border = "1px solid #aaa";
      card.style.padding = "10px";
      card.style.margin = "5px";
      card.innerHTML = `<strong>${event.name}</strong><br>
                        Date: ${event.date}<br>
                        Category: ${event.category}<br>
                        Seats: ${event.seats}`;
      container.appendChild(card);
    });
  })
  .catch(error => {
    loading.style.display = "none";
    container.textContent = "Error loading events: " + error.message;
  });
