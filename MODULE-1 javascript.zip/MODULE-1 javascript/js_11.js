document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registration-form");

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent page reload

    // Clear previous errors
    document.getElementById("name-error").textContent = "";
    document.getElementById("email-error").textContent = "";
    document.getElementById("event-error").textContent = "";

    const { name, email, event: selectedEvent } = form.elements;
    let valid = true;

    // Validate name
    if (name.value.trim() === "") {
      document.getElementById("name-error").textContent = "Name is required.";
      valid = false;
    }

    // Validate email
    if (!email.value.includes("@")) {
      document.getElementById("email-error").textContent = "Valid email required.";
      valid = false;
    }

    // Validate selected event
    if (selectedEvent.value === "") {
      document.getElementById("event-error").textContent = "Select an event.";
      valid = false;
    }

    if (valid) {
      alert(`✅ Registered ${name.value} for ${selectedEvent.value}!`);
      form.reset();
    }
  });
});
