console.log("Welcome to the Community Portal");

window.onload = function () {
  alert("Page fully loaded. Welcome to the Community Portal!");

  const eventName = "Community Clean-Up Drive";
  const eventDate = "2025-06-15";
  let availableSeats = 50;

  console.log(`📅 Event: ${eventName}\n📆 Date: ${eventDate}\n🪑 Available Seats: ${availableSeats}`);

  availableSeats--;
  console.log(`✅ One seat registered! Remaining Seats: ${availableSeats}`);
};
