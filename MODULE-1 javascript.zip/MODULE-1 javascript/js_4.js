console.log("Welcome to the Community Portal");

window.onload = function () {
  alert("Page fully loaded. Welcome to the Community Portal!");

  // Event list (global)
  const events = [];

  // ✅ Function to add a new event
  function addEvent(name, date, category, seats) {
    events.push({ name, date, category, seats });
  }

  // ✅ Closure to track total registrations per category
  function createCategoryRegistrationTracker() {
    const registrations = {};

    return function (category) {
      if (!registrations[category]) {
        registrations[category] = 0;
      }
      registrations[category]++;
      console.log(`📊 Total registrations in "${category}": ${registrations[category]}`);
    };
  }

  const trackRegistration = createCategoryRegistrationTracker(); // closure instance

  // ✅ Function to register a user to an event
  function registerUser(eventName) {
    const event = events.find(e => e.name === eventName);
    try {
      if (!event) throw new Error("Event not found.");
      if (new Date(event.date) < new Date()) throw new Error("Event is in the past.");
      if (event.seats <= 0) throw new Error("No seats available.");

      event.seats--;
      console.log(`🎟️ Registered for "${event.name}". Remaining seats: ${event.seats}`);
      trackRegistration(event.category);
    } catch (error) {
      console.error(`❌ Registration error: ${error.message}`);
    }
  }

  // ✅ Function to filter events by category (higher-order + callback)
  function filterEventsByCategory(category, callback) {
    const filtered = events.filter(e => e.category === category);
    callback(filtered);
  }

  // ▶️ Add some sample events
  addEvent("Beach Cleanup", "2025-06-30", "Environment", 25);
  addEvent("Food Drive", "2025-05-10", "Charity", 10); // past event
  addEvent("Coding Bootcamp", "2025-06-28", "Education", 15);
  addEvent("Tree Plantation", "2025-07-05", "Environment", 20);

  // ▶️ Register users
  registerUser("Beach Cleanup");
  registerUser("Tree Plantation");
  registerUser("Food Drive"); // should trigger error

  // ▶️ Filter Environment events and print them
  filterEventsByCategory("Environment", function (filteredEvents) {
    console.log("🌿 Filtered Environment Events:");
    filteredEvents.forEach(e => {
      console.log(`📅 ${e.name} on ${e.date} — Seats: ${e.seats}`);
    });
  });
};
