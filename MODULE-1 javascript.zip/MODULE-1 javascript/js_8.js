console.log("Task 8: Event Handling");

class Event {
  constructor(name, date, category, seats) {
    this.name = name;
    this.date = new Date(date);
    this.category = category;
    this.seats = seats;
  }

  checkAvailability() {
    const now = new Date();
    return this.date >= now && this.seats > 0;
  }

  registerUser() {
    if (!this.checkAvailability()) {
      throw new Error(`Cannot register for "${this.name}": Event full or past.`);
    }
    this.seats--;
  }
}

const events = [
  new Event("Beach Cleanup", "2025-06-30", "Environment", 3),
  new Event("Music Festival", "2025-08-10", "Music", 1),
  new Event("Coding Bootcamp", "2025-06-28", "Education", 15),
  new Event("Workshop on Baking", "2025-07-15", "Cooking", 20),
];

const container = document.querySelector("#events-container");
const categoryFilter = document.querySelector("#categoryFilter");
const searchInput = document.querySelector("#searchInput");

// Create event card element
function createEventCard(event) {
  const card = document.createElement("div");
  card.className = "event-card";

  const title = document.createElement("h3");
  title.textContent = event.name;
  card.appendChild(title);

  const details = document.createElement("p");
  details.textContent = `${event.category} | Date: ${event.date.toDateString()} | Seats: ${event.seats}`;
  card.appendChild(details);

  const button = document.createElement("button");
  button.textContent = event.checkAvailability() ? "Register" : "Full / Past";
  button.disabled = !event.checkAvailability();

  // Register button click handler (onclick)
  button.onclick = () => {
    try {
      event.registerUser();
      details.textContent = `${event.category} | Date: ${event.date.toDateString()} | Seats: ${event.seats}`;
      if (!event.checkAvailability()) {
        button.textContent = "Full / Past";
        button.disabled = true;
      }
      alert(`Successfully registered for ${event.name}!`);
    } catch (err) {
      alert(err.message);
    }
  };

  card.appendChild(button);
  return card;
}

// Render events based on filters
function renderEvents() {
  container.innerHTML = "";

  // Get current filter values
  const selectedCategory = categoryFilter.value;
  const searchText = searchInput.value.toLowerCase();

  // Filter events by category & search text
  let filteredEvents = events.filter(event => {
    const matchesCategory = selectedCategory === "All" || event.category === selectedCategory;
    const matchesSearch = event.name.toLowerCase().includes(searchText);
    return matchesCategory && matchesSearch;
  });

  if (filteredEvents.length === 0) {
    container.textContent = "No events found.";
    return;
  }

  filteredEvents.forEach(event => {
    const card = createEventCard(event);
    container.appendChild(card);
  });
}

// Event handlers for filter and search

// onchange for category filter
categoryFilter.onchange = () => {
  renderEvents();
};

// onkeydown for search input (you can also use oninput for live search)
searchInput.onkeydown = (event) => {
  // For smoother UX, you might want to wait for user to finish typing,
  // but for now we re-render on every keydown:
  setTimeout(renderEvents, 0);
};

// Initial render
renderEvents();
