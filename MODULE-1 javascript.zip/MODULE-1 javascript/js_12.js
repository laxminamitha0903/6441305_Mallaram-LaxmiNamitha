document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registration-form");
  const messageBox = document.getElementById("response-message");

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    // Clear previous messages
    messageBox.textContent = "";
    document.getElementById("name-error").textContent = "";
    document.getElementById("email-error").textContent = "";
    document.getElementById("event-error").textContent = "";

    const { name, email, event: selectedEvent } = form.elements;
    let valid = true;

    // Validation
    if (name.value.trim() === "") {
      document.getElementById("name-error").textContent = "Name is required.";
      valid = false;
    }
    if (!email.value.includes("@")) {
      document.getElementById("email-error").textContent = "Valid email required.";
      valid = false;
    }
    if (selectedEvent.value === "") {
      document.getElementById("event-error").textContent = "Select an event.";
      valid = false;
    }

    if (!valid) return;

    const userData = {
      name: name.value.trim(),
      email: email.value.trim(),
      event: selectedEvent.value
    };

    // Simulate loading state
    messageBox.style.color = "blue";
    messageBox.textContent = "⏳ Registering...";

    // Simulate delayed POST request
    setTimeout(() => {
      fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(userData)
      })
        .then(res => {
          if (!res.ok) {
            throw new Error("Server error");
          }
          return res.json();
        })
        .then(data => {
          messageBox.style.color = "green";
          messageBox.textContent = `✅ ${userData.name}, you are registered for ${userData.event}!`;
          form.reset();
        })
        .catch(err => {
          messageBox.style.color = "red";
          messageBox.textContent = `❌ Registration failed: ${err.message}`;
        });
    }, 1500); // 1.5 seconds delay
  });
});
